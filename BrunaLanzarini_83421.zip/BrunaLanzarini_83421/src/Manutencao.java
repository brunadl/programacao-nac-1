
public class Manutencao {
	private int codigo;
	private Cliente cliente;
	private Celular celular;

	public Manutencao(int codigo, Cliente cliente, Celular celular) {
		super();
		this.codigo = codigo;
		this.cliente = cliente;
		this.celular = celular;
	}
	
	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Celular getCelular() {
		return celular;
	}

	public void setCelular(Celular celular) {
		this.celular = celular;
	}

	public String toString() {
		String aux = "";
		
		aux += "C�digo --> " + codigo + "\n ";
		aux += "Cliente --> " + cliente + "\n ";
		aux += "Celular --> " + celular + "\n ";
		aux += " " + "\n";
		
		return aux;
	}
}
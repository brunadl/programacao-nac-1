import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class manutencaoDao {
    private PreparedStatement p; 
    private String sql; 
    private ResultSet rs; 
    private Connection connection; 
      
    public void inserir(Manutencao manutencao) {
        sql = "insert into java_manutencao (codigo_manutencao, nome_cliente, marca_celular, modelo_celular) values (?, ?, ?, ?)";
        connection = new sql().conectar();
       
        try {
            p = connection.prepareStatement(sql);
            p.setInt(1, manutencao.getCodigo());
            p.setString(2, manutencao.getCliente().getNome());
            p.setString(3, manutencao.getCelular().getMarca());
            p.setString(4, manutencao.getCelular().getModelo());
            p.execute();
        } 
        
        catch (SQLException e) {
           
            System.out.println("Erro ao inserir dados no banco\n" + e);  
        }
    }
}
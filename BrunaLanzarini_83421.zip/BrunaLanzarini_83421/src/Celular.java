
public class Celular implements Comparable<Celular> {
	private String marca;
	private String modelo;
	
	public Celular(String marca, String modelo) {
		super();
		this.marca = marca;
		this.modelo = modelo;
	}
	
	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public String toString() {
		String aux = "";
		
		aux += "Marca --> " + marca + "\n ";
		aux += "Modelo --> " + modelo + "\n ";
		aux += " " + "\n";
		
		return aux;
	}
	
	public int compareTo(Celular celular) {
        return marca.compareTo(celular.getMarca());
    }
}
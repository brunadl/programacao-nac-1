import java.sql.Connection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				
		List<Cliente> Clientes = new ArrayList<Cliente>();
		Clientes.add(new Cliente("111.111.111-11", "Selmini"));
		Clientes.add(new Cliente("222.222.222-22", "Parducci"));
		Clientes.add(new Cliente("333.333.333-33", "Aruan"));
		Clientes.add(new Cliente("444.444.444-44", "Ismael"));
		Clientes.add(new Cliente("555.555.555-55", "Paulo Sampaio"));
        //
        Collections.sort(Clientes);
       
        List<Celular> Celulares = new ArrayList<Celular>();
        Celulares.add(new Celular("Xiaomi", "Redmi Note 7"));
        Celulares.add(new Celular("Iphone", "Iphone 11"));
        Celulares.add(new Celular("Samsung", "S10"));
        Celulares.add(new Celular("Huawei", "P30"));
        Celulares.add(new Celular("Motorola", "One Vision"));
        //
        Collections.sort(Celulares);
       
        List<Manutencao> Manutencoes = new ArrayList<Manutencao>();       
        Manutencoes.add(new Manutencao(123, Clientes.get(0), Celulares.get(0)));
        Manutencoes.add(new Manutencao(231, Clientes.get(1), Celulares.get(1)));
        Manutencoes.add(new Manutencao(312, Clientes.get(2), Celulares.get(2)));
        Manutencoes.add(new Manutencao(120, Clientes.get(3), Celulares.get(3)));
        Manutencoes.add(new Manutencao(210, Clientes.get(4), Celulares.get(4)));

        
        Clientes.sort(Comparator.comparing(Cliente::getNome));
        System.out.println(Clientes.toString());
       
        Celulares.sort(Comparator.comparing(Celular::getMarca));
        System.out.println(Celulares.toString());
		
        sql conexao = new sql();
        Connection connection = conexao.conectar();
        System.out.println(conexao.conectar());
        
        manutencaoDao ManutencaoDao = new manutencaoDao();
         ManutencaoDao.inserir(Manutencoes.get(0));
         ManutencaoDao.inserir(Manutencoes.get(1));
         ManutencaoDao.inserir(Manutencoes.get(2)); 
         ManutencaoDao.inserir(Manutencoes.get(3)); 
         ManutencaoDao.inserir(Manutencoes.get(4)); 
         
	}

}